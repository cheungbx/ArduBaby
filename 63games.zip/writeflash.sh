#!/bin/bash
ls $1
python flashcart-writer.py $1

