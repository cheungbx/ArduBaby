#!/bin/bash
ls $1
python uploader.py $1

