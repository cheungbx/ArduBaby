#!/bin/bash
ls $1
python flashcart-builder.py $1

