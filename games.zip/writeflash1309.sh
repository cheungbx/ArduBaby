#!/bin/bash
ls $1
python flashcart-writer-1309.py $1

